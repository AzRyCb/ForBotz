By contributing, you agree to release your modifications under the MIT
license (see the file LICENSE-MIT).
